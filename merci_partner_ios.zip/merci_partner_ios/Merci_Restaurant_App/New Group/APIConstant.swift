//
//  APIConstant.swift
//  kestone
//
//  Created by Prankur on 04/07/17.
//  Copyright © 2017 Com.ripenApps. All rights reserved.
//

import Foundation
import UIKit


let baseApiUrl =  "http://52.15.78.190/merci/index.php/"
//let baseApiUrl =  "http://13.126.17.151/merci/index.php/"
//let baseApiUrl =  "http://13.126.99.14/merci/index.php/"



let kDataBaseName = "GoGreen"
let appDelegate  = UIApplication.shared.delegate as! AppDelegate
let action = "index"
let SIGNUP = "api/sign_up"
let GoogleClientid = "790288708718-f45d974lhbghmdnk45gi1mt3vlu5a0e9.apps.googleusercontent.com"

let AppName = "Partenaires Merci"
let LOGIN = "api/Login"
let FORGOTPASSWORD = "api/forget_password"
let get_city = "api/get_city"
let get_locality = "api/get_locality"
let get_street = "api/get_street"
let phone_varification = "api/phone_varification"
let inser_cardetail = "car_packages/"
let change_password = "api/"


// pop messgae

let sigupname = ""
let statuscode_0 = ""
let statuscode_3 = ""

// InitialVC
let errormasg = ""

//Edit_profile

