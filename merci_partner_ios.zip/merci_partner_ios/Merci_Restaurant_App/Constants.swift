//
//  Constants.swift
//  InstagramLogin_Example
//
//  Created by Ander Goig on 3/11/17.
//  Copyright © 2017 CocoaPods. All rights reserved.
//

import Foundation


struct Constants
{
   
    static var lang = "fr"
    
}

var selectedIndex = 0
